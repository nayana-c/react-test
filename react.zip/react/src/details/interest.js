import React from 'react';
import Line from '../line/line';

class Interest extends React.Component {
    constructor() {
       super();
     
     
    };
 
    render() {
       return (
          <div>
               <div>
               <img src='https://www.shareicon.net/data/2015/10/20/659226_music_512x512.png' height="40" width="40"/>
               </div>
               <div>
               <img src='https://iambooksboston.com/wp-content/uploads/2018/11/kisspng-vector-graphics-clip-art-speech-balloon-computer-i-free-speaking-icon-png-412815-download-speaking-ic-5b6c5f1286fff4.844723711533828882553.jpg' height="50" width="50"/>
               </div>
               <div>
               <img src='https://cdn.clipart.email/77279b34fc0dec158352eed313a04436_bollymoves-dance-academy-bharatanatyam-indian-classical-dance-_900-500.jpeg' height="50" width="50" />
               </div>
          </div>
       );
    }
 }
 export default Interest;
import React from 'react';
import Line from '../line/line';
import "./lhs.css";


class Details extends React.Component {
    constructor() {
       super();
             
    };
 
    render() {
       return (
          <div className="box-container">
          
          </div>
       );
    }
 }
 export default Details;
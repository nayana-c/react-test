import React from 'react';
import "./line.css";

class Line extends React.Component {
    constructor() {
       super();
    
    };
 
    render() {
       return (
          <div className="line">
          </div>
       );
    }
 }
 export default Line;
